<?php

$i = new Interceptor();
$w = new Wizard();
$w->init();
$i->render();
$u = new Utils();

