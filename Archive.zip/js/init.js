$(document).ready(function(){

    execute.run();

});